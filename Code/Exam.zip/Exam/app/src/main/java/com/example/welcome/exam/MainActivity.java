package com.example.welcome.exam;

import android.content.Intent;
import android.hardware.SensorEventListener;
import android.os.Bundle;
import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.text.Html;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import static android.provider.AlarmClock.EXTRA_MESSAGE;


public class MainActivity extends Activity implements SensorEventListener {
    // ...
    public static final int TIME_CONSTANT = 30;

    private SensorManager mSensorManager = null;
    TextView A;
    TextView G;
    TextView M;
    TextView L;

    // angular speeds from gyro
    private float[] gyro = new float[3];

    // magnetic field vector
    private float[] magnet = new float[3];

    // accelerometer vector
    private float[] accel = new float[3];

    private float[] light = new float[3];

    // orientation angles from accel and magnet
    private float[] accMagOrientation = new float[3];

    // final orientation angles from sensor fusion
    private float[] fusedOrientation = new float[3];
     String sx,sy,sz,sw;

    // accelerometer and magnetometer based rotation matrix
       public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
           A = (TextView) findViewById (R.id.textView1);
           M = (TextView) findViewById (R.id.textView2);
           L = (TextView) findViewById (R.id.textView3);
           G = (TextView) findViewById (R.id.textView4);
           // get sensorManager and initialise sensor listeners
        mSensorManager = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        initListeners();

    }

    ;

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public void initListeners() {
        mSensorManager.registerListener(this,
                mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
                SensorManager.SENSOR_DELAY_FASTEST);

        mSensorManager.registerListener(this,
                mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
                SensorManager.SENSOR_DELAY_FASTEST);

        mSensorManager.registerListener(this,
                mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
                SensorManager.SENSOR_DELAY_FASTEST);
        mSensorManager.registerListener(this,
                mSensorManager.getDefaultSensor(Sensor.TYPE_LIGHT),
                SensorManager.SENSOR_DELAY_FASTEST);


    }

    public void onSensorChanged(SensorEvent event) {
        switch (event.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER:
                // copy new accelerometer data into accel array
                // then calculate new orientation
                float accel = event.values[1];
                sx = " " + accel;
                A.setText(sx);
                break;

            case Sensor.TYPE_GYROSCOPE:
                // process gyro data
               //ystem.arraycopy(event.values, 0, gyro, 3);
                float gyro = event.values[2];
                sy = "" + gyro ;
                G.setText(sy);

                break;

            case Sensor.TYPE_MAGNETIC_FIELD:
                // copy new magnetometer data into magnet array
                float magnet = event.values[0];
                sz = "" + magnet ;
                M.setText(sz);

                break;

            case Sensor.TYPE_LIGHT:
                // copy new magnetometer data into magnet array
                float light = event.values[0];
                sw = " " + light;
                L.setText(sw);

                break;
        }
    }

    }